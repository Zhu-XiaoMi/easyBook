Page({
	/**
	 * 页面的初始数据
	 */
	data:{
		inputValue:"",
		book:"",
		result:false,
		id:0
	},
	searchText:function(e){
		this.setData({
			inputValue:e.detail.value
		})
	},
    query:function(){
        var that = this
    	const db = wx.cloud.database()
        db.collection('novelinfo').where({
        	title: that.data.inputValue
        }).field({
            title:true,
            id:true
        })
        .get().then(res=>{
        	that.setData({
               	book:res.data[0].title,
               	id:res.data[0].id,
               	result:true
            })
        })	

    },
    toRead:function(){
    	wx.navigateTo({
    		url:'../details/details?novelid=' + this.data.id
    	})
    },
	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {
		
	},

	/**
	 * 生命周期函数--监听页面初次渲染完成
	 */
	onReady: function () {
		
	},

	/**
	 * 生命周期函数--监听页面显示
	 */
	onShow: function () {

	},

	/**
	 * 生命周期函数--监听页面隐藏
	 */
	onHide: function () {

	},

	/**
	 * 生命周期函数--监听页面卸载
	 */
	onUnload: function () {

	},

	/**
	 * 页面相关事件处理函数--监听用户下拉动作
	 */
	onPullDownRefresh: function () {

	},

	/**
	 * 页面上拉触底事件的处理函数
	 */
	onReachBottom: function () {

	},

	/**
	 * 用户点击右上角转发
	 */
	onShareAppMessage: function () {

	},

	/**
	 * 页面滚动触发事件的处理函数
	 */
	onPageScroll: function () {

	},

	/**
	 * 当前是 tab 页时，点击 tab 时触发
	 */
	onTabItemTap: function(item) {

	},

})