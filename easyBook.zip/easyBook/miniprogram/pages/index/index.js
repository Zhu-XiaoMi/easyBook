//index.js
//获取应用实例
const app = getApp()
Page({
    /**
     * 页面的初始数据
     */
    data:{
        navbar: ['男生', '女生'], 
        lists:[ ],
        currentTab: 0
    },

    feelRead:function(e){

        wx.navigateTo({
          url:'../read/read?chapterid=1'+ '&novelid=' + e.currentTarget.dataset.novelid 
        })
    },
    
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var that = this
        const db = wx.cloud.database()
        db.collection('novelinfo').where({
            recommend:true
        }).orderBy('updatetime','desc').limit(5).field({
            id:true,
            img:true,
            title:true,
            grade:true,
            author:true,
            description:true
        })
        .get().then(res=>{
            that.setData({
                    lists:res.data
            })
        })
       wx.clearStorage()
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
        setTimeout(function (){
          wx.stopPullDownRefresh()
        }, 1000)
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角转发
     */
    onShareAppMessage: function () {

    },

    /**
     * 页面滚动触发事件的处理函数
     */
    onPageScroll: function () {

    },

    /**
     * 当前是 tab 页时，点击 tab 时触发
     */
    onTabItemTap: function(item) {

    },
     searchBtn:function(){
        wx.navigateTo({
        url: '../search/search'
    })
    },
    navbarTap: function(e){ 
        this.setData({ 
            currentTab: e.currentTarget.dataset.idx 
        }) 
        
    }
})

