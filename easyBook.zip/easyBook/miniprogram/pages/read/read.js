Page({
    /**
     * 页面的初始数据
     */
    data:{
        open: false,
        nav_list: [],
        title:"",
        img:"",
        content:"",
        chapterid:0,
        novelid:0,
        look:false,
        has:false,
        last_data:[],
        count:0,
        noveltitle:""
    },
    
    off_canvas: function(){

        this.data.open ? this.setData({open: false}) :this.setData({open: true});
        this.setData({
            look:false
        })
  },
    joinShelf:function(){
       
          var img = this.data.img
          var getImg = wx.getStorageSync("加入书架的图片") || []
          getImg.push(img)
          wx.setStorageSync("加入书架的图片", getImg)
          var noveltitle = this.data.noveltitle
          var arr = wx.getStorageSync("加入书架的小说") || []
          arr.push(noveltitle)
          wx.setStorageSync("加入书架的小说", arr)
          this.setData({
               has:true
          })
          wx.showToast({
            title: '已加入书架',
            icon: 'success',
            duration: 2000
          })

  },
  lookShelf:function(){

    this.data.look ? this.setData({look: false}) :this.setData({look: true});
  },
  toChapterLast:function(){
    var chapterid = this.data.chapterid
    var novelid = this.data.novelid
    if(chapterid > 1){
      this.setData({
        chapterid: chapterid-1
      })
      this.getChapterInfo(this.data.chapterid,this.data.novelid);

    }
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 3
    })

    
  }, 
  tolist:function(e){

    this.getChapterInfo(e.currentTarget.dataset.chapterid,e.currentTarget.dataset.novelid)
    this.setData({
            open:false
        })
  },

  toChapterNext:function(){
    var chapterid = this.data.chapterid
    var count = this.data.count 
    var novelid = this.data.novelid
    if(chapterid < count){
      this.setData({
        chapterid: chapterid+1
      })
      this.getChapterInfo(this.data.chapterid,this.data.novelid);
    }
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 1
    })
  },

  getChapterInfo:function(chapterid,novelid) {
    var that = this;
        const db = wx.cloud.database()
        db.collection('chapterinfo').where({
          novelid:novelid,
          chapterid:chapterid
        }).field({
              title:true,
              novelid:true,
              content:true
          }).get().then(res=>{
            var str = res.data[0].content.split('&hc').join('\n') 

                that.setData({
                    content:str,
                    title:res.data[0].title,
                    novelid:novelid
                  })
              })
         

  },
  getChapterImg:function(){
    var that = this;
    const db = wx.cloud.database()
    db.collection('novelinfo').where({
        id:that.data.novelid
    }).field({
        img:true,
        title:true
    }).get().then(res=>{
        that.setData({
          img:res.data[0].img,
          noveltitle:res.data[0].title
        })
        return res;
    }).then(data=>{
      var arred = wx.getStorageSync("加入书架的小说")
         for(var index in arred){
           if(this.data.noveltitle == arred[index]){
               this.setData({
               has:true
             })
               
          }
        }
    })
  },

   getChapterTitle:function(novelid){
     var that = this;
        const db = wx.cloud.database()
        db.collection('chapterinfo').where({
              novelid:novelid
        }).field({
          title:true,
          novelid:true,
          chapterid:true

        }).get().then(res=>{
          that.setData({
            nav_list:res.data
          })
           
        })
  },
  getChapterCount(novelid){
    var that = this;
        const db = wx.cloud.database()
     db.collection('chapterinfo').where({
              novelid:novelid
          }).count().then(res=>{
                that.setData({
                    count:res.total
                })
            })
  },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
  

        var that = this
        var chapterid = parseInt(options.chapterid)
        var novelid = parseInt(options.novelid)
        that.setData({
            chapterid:chapterid,
            novelid:novelid
        })

        that.getChapterInfo(chapterid,novelid)
        that.getChapterTitle(novelid)
        that.getChapterCount(novelid)
        that.getChapterImg()
         
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角转发
     */
    onShareAppMessage: function () {

    },

    /**
     * 页面滚动触发事件的处理函数
     */
    onPageScroll: function () {

    },

    /**
     * 当前是 tab 页时，点击 tab 时触发
     */
    onTabItemTap: function(item) {

    },
})