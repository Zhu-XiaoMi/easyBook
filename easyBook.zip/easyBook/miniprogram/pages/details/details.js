var util = require('../../utils/dateFormat');
console.log(util)

Page({
    data: {
        listIcon: "../../assets/images/add.png",
        nav_list: [],
   		  open: false,
        count:0,
        type :"",
        info:[],
        catalog:[],
        novelid:0,
        has:false,
        title:"",
        updatetime:""

    },
   off_canvas: function(){
    this.data.open ? this.setData({open: false}) :this.setData({open: true});
  },

  toRead:function(){
     wx.navigateTo({
       url:"../read/read?chapterid=1" + "&novelid=" + this.data.novelid
     })
  },
  toShelf:function(){
    var img = this.data.info.img
    var getImg = wx.getStorageSync("加入书架的图片") || [];
    getImg.push(img)
    wx.setStorageSync("加入书架的图片", getImg)
    var arr = wx.getStorageSync("加入书架的小说") || [];
    arr.push(this.data.title)
    wx.setStorageSync("加入书架的小说", arr)
    this.setData({
      has:true
    })
   
  },

  onLoad: function (options) {
    
    var that = this
    var num = 0
        const db = wx.cloud.database()
        db.collection('novelinfo').where({
            id:1
        })
        .get().then(res=>{
          
                let updateTime = util.formatDate(res.data[0].updatetime);
                that.setData({
                     info:res.data[0],
                     title:res.data[0].title,
                     updatetime: updateTime
                })
           
                db.collection('noveltype').where({
                  id:res.data[0].typeid
                }).field({
                  type:true,
                }).get().then(res=>{
                  that.setData({
                      type:res.data[0].type,
                  })

                })
                return res;
        })
        .then(data => {
           var arr = wx.getStorageSync("加入书架的小说")
           if(arr){
              for(var index in arr){
                if(that.data.title == arr[index]){
                   that.setData({
                     has:true
                   })
                }
              }
           }
        })
// parseInt(options.novelid)
        db.collection('chapterinfo').where({
            novelid:1
        }).field({
          chapterid:true,
          novelid:true,
          count:true,
          title:true,
          updatetime:true,
          content:true
        })
        .get().then(res=> {
                for (var index in res.data) {
                  num +=res.data[index].count             
                }
                that.setData({
                    count:num,
                    catalog:res.data,
                    nav_list:res.data,
                    novelid:parseInt(options.novelid)
                })

            })
       

       
        
  }
})