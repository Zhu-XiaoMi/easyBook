//index.js
//获取应用实例
const UPDATE_MILE_SEC = 100; //自动关闭、打开 每次刷新毫秒

Page({
    data: {
        imgs:[],
        novels:[]
    },
    toRead:function(e){
        const db = wx.cloud.database()
        db.collection('novelinfo').where({
            title:String(e.currentTarget.dataset.title)
        }).field({
            id:true
        }).get().then(res=>{
                wx.navigateTo({
                    url:'../details/details?novelid=' + res.data[0].id
                })
                console.log(res.data[0].id);
            })
        
    },
    onLoad: function (options) {
        var that = this
        var novel = wx.getStorageSync("加入书架的小说")
        var img = wx.getStorageSync("加入书架的图片")
        
            
                this.setData({
                    imgs:img
                })
            
            
        

        
            this.setData({
                 novels:novel
            })
        
    
    }
})